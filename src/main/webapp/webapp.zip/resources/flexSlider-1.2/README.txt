jQuery FlexSlider v1.2
http://flex.madebymufffin.com

Copyright (c) 2011 Tyler Smith

---

Changelog:

v1.2 2011-08-16
  - Fixed some code redundancies
  - Added "randomize" property to randomize slide oder on pageLoad
  - Added "touchSwipe" property for swipe gestures on iOS and Android devices (no Android device to test this, but it should work)
  - Fixed minor bugs in jQuery 1.3.2 where navigation was not appending correctly
--

v1.0 2011-08-14 (Release)
	- Free to use under the MIT license