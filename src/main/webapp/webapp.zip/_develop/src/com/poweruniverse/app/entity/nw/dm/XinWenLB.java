package com.poweruniverse.app.entity.nw.dm;
import com.poweruniverse.app.entity.nw.dm.base.BaseXinWenLB;

/*
* 实体类：新闻类别
*/
public class XinWenLB  extends BaseXinWenLB {
	private static final long serialVersionUID = 1L;

	// constructors
	public XinWenLB () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public XinWenLB (java.lang.Integer id) {
		super(id);
	}

	protected void initialize () {}
	
	
}