package com.poweruniverse.app.entity.nw.dm;
import com.poweruniverse.app.entity.nw.dm.base.BaseXinWen;

/*
* 实体类：XinWen
*/
public class XinWen  extends BaseXinWen {
	private static final long serialVersionUID = 1L;

	// constructors
	public XinWen () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public XinWen (java.lang.Integer id) {
		super(id);
	}

	protected void initialize () {}
	
	
}