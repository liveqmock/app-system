function onTreeLoaded(){
	var treeInst = LUI.Tree.getInstance('moduleFileTree');
	treeInst.getRootNode().expand();
}