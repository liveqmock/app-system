//页面加载完成事件
function onPageLoad(){
	var _tab_tab = LUI.Tab.createNew({
        "name":"tab",
        "renderto":"#tab_menu",
        "autoRender":"true",
        "activeClass":"actived"
    });
}

