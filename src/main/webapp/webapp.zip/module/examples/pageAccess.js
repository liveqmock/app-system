console.info('地址栏页面加载完成');
var ass = 1;
ass = ass+1;